﻿using MediatR;

namespace Escrow.Api.Domain.Common;

public abstract class BaseEvent : INotification
{
}
