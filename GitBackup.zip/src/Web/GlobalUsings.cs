global using Ardalis.GuardClauses;
global using Escrow.Api.Web.Infrastructure;
global using MediatR;
