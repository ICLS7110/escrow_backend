﻿using Microsoft.AspNetCore.Identity;

namespace Escrow.Api.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{
}
