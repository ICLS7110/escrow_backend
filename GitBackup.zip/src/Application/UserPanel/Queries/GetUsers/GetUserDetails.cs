﻿using Escrow.Api.Application.Common.Interfaces;
using Escrow.Api.Application.Common.Mappings;
using Escrow.Api.Application.Common.Models;
using Escrow.Api.Domain.Entities.UserPanel;

namespace Escrow.Api.Application.UserPanel.Queries.GetUsers;

public record GetUserDetailsQuery : IRequest<UserDetail>
{
    public string UserId { get; init; } = string.Empty;
    /* public int PageNumber { get; init; } = 1;
     public int PageSize { get; init; } = 10;*/
}

public class GetGetUserDetailsQueryHandler : IRequestHandler<GetUserDetailsQuery, UserDetail>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;

    public GetGetUserDetailsQueryHandler(IApplicationDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<UserDetail> Handle(GetUserDetailsQuery request, CancellationToken cancellationToken)
    {
        return await _context.UserDetails
            .Where(x => x.UserId == request.UserId).FirstAsync(cancellationToken);
        //.OrderBy(x => x.FullName)
        //.ProjectTo<UserDetailDto>(_mapper.ConfigurationProvider);
        //.PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
