﻿namespace Escrow.Api.Application.Common.Interfaces;

public interface IUser
{
    string? Id { get; }
}
